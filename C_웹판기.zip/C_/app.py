from flask import Flask, render_template, request, redirect, url_for, session, flash, g, jsonify, send_from_directory
import sqlite3
from datetime import datetime
import os
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
import secrets
import smtplib
from email.mime.text import MIMEText

DATABASE = 'vending.db'
UPLOAD_FOLDER = 'static/deposit_images'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

def send_verification_email(to_email, token):
    smtp_host = "smtp.gmail.com"
    smtp_port = 587
    smtp_user = "koty0516@gmail.com"
    smtp_pass = "idmfpaxsklkmhxto"
    subject = "이메일 인증 - 포인트 자판기"
    body = f"이메일 인증을 위해 아래 링크를 클릭하세요:\n\nhttp://192.168.0.29:2048/verify_email?token={token}"
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = smtp_user
    msg['To'] = to_email
    try:
        s = smtplib.SMTP(smtp_host, smtp_port)
        s.starttls()
        s.login(smtp_user, smtp_pass)
        s.sendmail(smtp_user, [to_email], msg.as_string())
        s.quit()
    except Exception as e:
        print("메일 전송 실패:", e)

def send_reset_email(to_email, token):
    smtp_host = "smtp.gmail.com"
    smtp_port = 587
    smtp_user = "koty0516@gmail.com"
    smtp_pass = "idmfpaxsklkmhxto"
    subject = "비밀번호 재설정 - 포인트 자판기"
    body = f"비밀번호 재설정을 위해 아래 링크를 클릭하세요:\n\nhttp://192.168.0.29:2048/reset_password?token={token}"
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = smtp_user
    msg['To'] = to_email
    try:
        s = smtplib.SMTP(smtp_host, smtp_port)
        s.starttls()
        s.login(smtp_user, smtp_pass)
        s.sendmail(smtp_user, [to_email], msg.as_string())
        s.quit()
    except Exception as e:
        print("메일 전송 실패:", e)

def create_admin_if_not_exists():
    db = sqlite3.connect(DATABASE)
    db.row_factory = sqlite3.Row
    admin = db.execute("SELECT * FROM users WHERE username = ?", ('pee',)).fetchone()
    if not admin:
        password_hash = generate_password_hash('pee')
        db.execute(
            "INSERT INTO users (username, password, password_hash, email, email_verified, points) VALUES (?, ?, ?, ?, ?, ?)",
            ('pee', 'pee', password_hash, 'admin@admin.com', 1, 0)
        )
        db.commit()
    db.close()

def init_db():
    db = sqlite3.connect(DATABASE)
    db.row_factory = sqlite3.Row
    db.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT,
            password_hash TEXT,
            email TEXT,
            email_verified INTEGER DEFAULT 0,
            points INTEGER DEFAULT 0
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            price INTEGER,
            stock INTEGER
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS purchases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            product_id INTEGER,
            quantity INTEGER,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id),
            FOREIGN KEY(product_id) REFERENCES products(id)
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            product_id INTEGER,
            content TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id),
            FOREIGN KEY(product_id) REFERENCES products(id)
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS notice (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            content TEXT
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS charge_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            depositor TEXT,
            amount INTEGER,
            status TEXT DEFAULT '대기중',
            requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            approved_at TIMESTAMP,
            deposit_image TEXT,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS email_verifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            token TEXT,
            is_verified INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS password_resets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            token TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS coupons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE,
            description TEXT,
            max_uses INTEGER,
            used_count INTEGER DEFAULT 0,
            amount INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS coupon_usages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            coupon_id INTEGER,
            used_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id),
            FOREIGN KEY(coupon_id) REFERENCES coupons(id)
        )
    """)
    if not db.execute("SELECT * FROM notice WHERE id=1").fetchone():
        db.execute("INSERT INTO notice (id, content) VALUES (1, '')")
        db.commit()
    db.close()
    create_admin_if_not_exists()

app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

@app.route('/deposit_image/<filename>')
def deposit_image(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/')
def index():
    db = get_db()
    products = db.execute("SELECT * FROM products").fetchall()
    purchases = []
    user = None
    notice = db.execute("SELECT content FROM notice WHERE id=1").fetchone()
    notice_content = notice["content"] if notice else ""
    if 'user_id' in session and session['user_id'] != 'pee':
        user = db.execute("SELECT * FROM users WHERE id=?", (session['user_id'],)).fetchone()
        purchases = db.execute("""
            SELECT p.*, pr.name, pr.price FROM purchases p
            JOIN products pr ON p.product_id = pr.id
            WHERE p.user_id=?
            ORDER BY p.timestamp DESC LIMIT 5
        """, (session['user_id'],)).fetchall()
    return render_template('index.html', products=products, purchases=purchases, user=user, notice_content=notice_content)

@app.route('/', methods=['POST'])
def buy():
    if 'user_id' not in session or session['user_id'] == 'pee':
        flash('로그인 후 이용하세요.', 'danger')
        return redirect(url_for('index'))
    product_id = request.form.get('product_id')
    try:
        quantity = int(request.form.get('quantity', 1))
    except Exception:
        quantity = 1
    if quantity < 1:
        flash('수량은 1개 이상이어야 합니다.', 'danger')
        return redirect(url_for('index'))
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id=?", (session['user_id'],)).fetchone()
    product = db.execute("SELECT * FROM products WHERE id=?", (product_id,)).fetchone()
    if not product or product['stock'] < quantity:
        flash('상품의 재고가 부족합니다.', 'danger')
        return redirect(url_for('index'))
    total_price = product['price'] * quantity
    if user['points'] < total_price:
        flash('포인트가 부족합니다.', 'danger')
        return redirect(url_for('index'))
    db.execute("INSERT INTO purchases (user_id, product_id, quantity) VALUES (?, ?, ?)", (user['id'], product_id, quantity))
    db.execute("UPDATE users SET points=points-? WHERE id=?", (total_price, user['id']))
    db.execute("UPDATE products SET stock=stock-? WHERE id=?", (quantity, product_id))
    db.commit()
    flash('구매가 완료되었습니다.', 'success')
    return redirect(url_for('index'))

@app.route('/admin_products', methods=['GET', 'POST'])
def admin_products():
    if not session.get('is_admin'):
        flash('관리자만 접근 가능합니다.', 'danger')
        return redirect(url_for('login'))
    db = get_db()
    if request.method == 'POST':
        # 신규 제품 추가
        if request.form.get('add_product'):
            name = request.form.get('name', '').strip()
            price = request.form.get('price', '').strip()
            stock = request.form.get('stock', '').strip()
            if not name or price == '' or stock == '':
                flash('제품명, 가격, 재고를 모두 입력하세요.', 'danger')
            else:
                try:
                    price = int(price)
                    stock = int(stock)
                    db.execute("INSERT INTO products (name, price, stock) VALUES (?, ?, ?)", (name, price, stock))
                    db.commit()
                    flash('새 제품이 추가되었습니다.', 'success')
                except Exception:
                    flash('제품 추가 실패.', 'danger')
            return redirect(url_for('admin_products'))

        # 제품 삭제
        if request.form.get('delete_id'):
            delete_id = request.form.get('delete_id')
            try:
                db.execute("DELETE FROM products WHERE id=?", (delete_id,))
                db.commit()
                flash('제품이 삭제되었습니다.', 'success')
            except Exception:
                flash('제품 삭제 실패.', 'danger')
            return redirect(url_for('admin_products'))

        # 가격/재고 수정
        edit_id = request.form.get('edit_id')
        price = request.form.get('price')
        stock = request.form.get('stock')
        if edit_id:
            if price is not None and price != '':
                try:
                    price = int(price)
                    db.execute("UPDATE products SET price=? WHERE id=?", (price, edit_id))
                    db.commit()
                    flash('가격이 수정되었습니다.', 'success')
                except Exception:
                    flash('가격 수정 실패.', 'danger')
            if stock is not None and stock != '':
                try:
                    stock = int(stock)
                    db.execute("UPDATE products SET stock=? WHERE id=?", (stock, edit_id))
                    db.commit()
                    flash('재고가 수정되었습니다.', 'success')
                except Exception:
                    flash('재고 수정 실패.', 'danger')
            return redirect(url_for('admin_products'))

    products = db.execute("SELECT * FROM products").fetchall()
    return render_template('admin_products.html', products=products)

@app.route('/admin_purchases')
def admin_purchases():
    if not session.get('is_admin'):
        flash('관리자만 접근 가능합니다.', 'danger')
        return redirect(url_for('login'))
    db = get_db()
    purchases = db.execute("""
        SELECT p.id, p.timestamp, u.username, pr.name AS product_name, pr.price, p.quantity
        FROM purchases p
        JOIN users u ON p.user_id = u.id
        JOIN products pr ON p.product_id = pr.id
        ORDER BY p.timestamp DESC
    """).fetchall()
    return render_template('admin_purchases.html', purchases=purchases)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']

        db = get_db()
        user = db.execute("SELECT * FROM users WHERE username=? OR email=?", (username, email)).fetchone()
        if user:
            flash('이미 존재하는 아이디 또는 이메일입니다.', 'danger')
            return render_template('register.html')
        password_hash = generate_password_hash(password)
        db.execute("INSERT INTO users (username, password, password_hash, email, email_verified, points) VALUES (?, ?, ?, ?, 0, 0)",
                   (username, password, password_hash, email))
        db.commit()
        user_id = db.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone()['id']
        token = secrets.token_urlsafe(32)
        db.execute("INSERT INTO email_verifications (user_id, token) VALUES (?, ?)", (user_id, token))
        db.commit()
        send_verification_email(email, token)
        flash('회원가입이 완료되었습니다. 이메일 인증을 진행해주세요.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/verify_email')
def verify_email():
    token = request.args.get('token')
    db = get_db()
    row = db.execute("SELECT ev.*, u.email FROM email_verifications ev JOIN users u ON ev.user_id = u.id WHERE token=? AND is_verified=0", (token,)).fetchone()
    if row:
        db.execute("UPDATE email_verifications SET is_verified=1 WHERE id=?", (row['id'],))
        db.execute("UPDATE users SET email_verified=1 WHERE id=?", (row['user_id'],))
        db.commit()
        flash("이메일 인증이 완료되었습니다! 로그인해주세요.", "success")
    else:
        flash("유효하지 않은 인증 링크 또는 이미 인증된 계정입니다.", "danger")
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if username == 'pee':
            db = get_db()
            admin = db.execute("SELECT * FROM users WHERE username=?", ('pee',)).fetchone()
            if admin and check_password_hash(admin['password_hash'], password):
                session['user_id'] = 'pee'
                session['is_admin'] = True
                flash('관리자로 로그인되었습니다.', 'success')
                return redirect(url_for('index'))
            else:
                flash('비밀번호가 일치하지 않습니다.', 'danger')
                return render_template('login.html')

        user = get_db().execute(
            "SELECT * FROM users WHERE username=?",
            (username,)
        ).fetchone()
        if user:
            if not check_password_hash(user['password_hash'], password):
                flash('비밀번호가 일치하지 않습니다.', 'danger')
                return render_template('login.html')
            if not user['email_verified']:
                flash('이메일 인증 후 로그인 가능합니다.', 'danger')
                return redirect(url_for('login'))
            session['user_id'] = user['id']
            session['is_admin'] = False
            flash('로그인 성공', 'success')
            return redirect(url_for('index'))
        else:
            flash('로그인 실패', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('로그아웃되었습니다.', 'info')
    return redirect(url_for('index'))

@app.route('/my_purchases')
def my_purchases():
    if 'user_id' not in session or session['user_id'] == 'pee':
        flash('로그인 후 이용하세요.', 'danger')
        return redirect(url_for('login'))
    db = get_db()
    if session['user_id'] == 'pee':
        flash('관리자는 구매내역을 볼 수 없습니다.', 'danger')
        return redirect(url_for('index'))
    user = db.execute("SELECT * FROM users WHERE id=?", (session['user_id'],)).fetchone()
    purchases = db.execute("""
        SELECT p.*, pr.name, pr.price FROM purchases p
        JOIN products pr ON p.product_id = pr.id
        WHERE p.user_id=?
        ORDER BY p.timestamp DESC
    """, (session['user_id'],)).fetchall()
    return render_template('my_purchases.html', purchases=purchases, user=user)

@app.route('/charge_request', methods=['GET', 'POST'])
def charge_request():
    if request.method == 'GET':
        return render_template('charge_request.html')
    if 'user_id' not in session or session['user_id'] == 'pee':
        return jsonify({'ok': False, 'msg': '로그인 필요'})
    depositor = request.form.get('depositor')
    amount = request.form.get('amount')
    try:
        amount_int = int(amount)
        if amount_int < 1000:
            return jsonify({'ok': False, 'msg': '최소 충전금액은 1000원입니다.'})
    except Exception:
        return jsonify({'ok': False, 'msg': '충전금액을 올바르게 입력하세요.'})
    file = request.files.get('deposit_image')
    deposit_image = None
    if file and allowed_file(file.filename):
        filename = secure_filename(f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{file.filename}")
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        deposit_image = filename
    db = get_db()
    db.execute("INSERT INTO charge_requests (user_id, depositor, amount, deposit_image) VALUES (?, ?, ?, ?)",
               (session['user_id'], depositor, amount, deposit_image))
    db.commit()
    return jsonify({'ok': True})

@app.route('/charge_history')
def charge_history():
    if 'user_id' not in session or session['user_id'] == 'pee':
        flash("로그인 후 이용 가능합니다.", "danger")
        return redirect(url_for('login'))
    db = get_db()
    charge_requests = db.execute("""
        SELECT * FROM charge_requests
        WHERE user_id=?
        ORDER BY requested_at DESC
    """, (session['user_id'],)).fetchall()
    return render_template('charge_history.html', charge_requests=charge_requests)

@app.route('/admin_charge', methods=['GET', 'POST'])
def admin_charge():
    if not session.get('is_admin'):
        flash('관리자만 접근 가능합니다.', 'danger')
        return redirect(url_for('login'))
    db = get_db()
    if request.method == 'POST':
        req_id = request.form.get('req_id')
        action = request.form.get('action')
        if req_id and action:
            req = db.execute("SELECT * FROM charge_requests WHERE id=?", (req_id,)).fetchone()
            if req and req['status'] == '대기중':
                if action == 'approve':
                    db.execute("UPDATE users SET points = points + ? WHERE id = ?", (req['amount'], req['user_id']))
                    db.execute("UPDATE charge_requests SET status='완료', approved_at=? WHERE id=?",
                               (datetime.now(), req_id))
                    db.commit()
                    flash("충전 승인 완료", "success")
                elif action == 'reject':
                    db.execute("UPDATE charge_requests SET status='거절', approved_at=? WHERE id=?",
                               (datetime.now(), req_id))
                    db.commit()
                    flash("충전 요청이 거절되었습니다.", "info")
    requests = db.execute("""
        SELECT cr.*, u.username 
        FROM charge_requests cr 
        JOIN users u ON cr.user_id = u.id
        WHERE cr.status='대기중' ORDER BY cr.requested_at DESC
    """).fetchall()
    notice = db.execute("SELECT content FROM notice WHERE id=1").fetchone()
    notice_content = notice["content"] if notice else ""
    return render_template("admin_charge.html", requests=requests, notice_content=notice_content)

@app.route('/admin_notice', methods=['POST'])
def admin_notice():
    if not session.get('is_admin'):
        return redirect(url_for('login'))
    content = request.form.get('notice_content', '')
    db = get_db()
    db.execute("UPDATE notice SET content=? WHERE id=1", (content,))
    db.commit()
    flash("공지사항이 수정되었습니다.", "success")
    return redirect(url_for('admin_charge'))

@app.route('/admin_users', methods=['GET', 'POST'])
def admin_users():
    if not session.get('is_admin'):
        flash('관리자만 접근 가능합니다.', 'danger')
        return redirect(url_for('login'))
    db = get_db()
    if request.method == 'POST':
        user_id = request.form.get('user_id')
        point_val = request.form.get('points')
        email_verified_val = request.form.get('email_verified')
        if user_id is not None:
            if point_val is not None:
                try:
                    point_val = int(point_val)
                    db.execute("UPDATE users SET points=? WHERE id=?", (point_val, user_id))
                    db.commit()
                    flash(f'사용자 ID {user_id}의 포인트가 {point_val}P로 변경되었습니다.', 'success')
                except Exception:
                    flash('포인트 수정에 실패했습니다.', 'danger')
            if email_verified_val is not None:
                try:
                    email_verified_val = int(email_verified_val)
                    db.execute("UPDATE users SET email_verified=? WHERE id=?", (email_verified_val, user_id))
                    db.commit()
                    flash(f'사용자 ID {user_id}의 이메일 인증 상태가 변경되었습니다.', 'success')
                except Exception:
                    flash('이메일 인증 상태 변경에 실패했습니다.', 'danger')
        return redirect(url_for('admin_users'))
    users = db.execute("SELECT id, username, points, email_verified FROM users ORDER BY id ASC").fetchall()
    return render_template('admin_users.html', users=users)

@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form['email']
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if not user:
            flash("등록되지 않은 이메일입니다.", "danger")
            return redirect(url_for('forgot_password'))
        token = secrets.token_urlsafe(32)
        db.execute("INSERT INTO password_resets (user_id, token) VALUES (?, ?)", (user['id'], token))
        db.commit()
        send_reset_email(email, token)
        flash("비밀번호 재설정 이메일이 전송되었습니다.", "info")
        return redirect(url_for('login'))
    return render_template('forgot_password.html')

@app.route('/reset_password', methods=['GET', 'POST'])
def reset_password():
    token = request.args.get('token') if request.method == 'GET' else request.form.get('token')
    db = get_db()
    row = db.execute("SELECT * FROM password_resets WHERE token=?", (token,)).fetchone()
    if not row:
        flash("유효하지 않거나 만료된 링크입니다.", "danger")
        return redirect(url_for('login'))
    if request.method == 'POST':
        new_pass = request.form['password']
        password_hash = generate_password_hash(new_pass)
        db.execute("UPDATE users SET password_hash=? WHERE id=?", (password_hash, row['user_id']))
        db.execute("DELETE FROM password_resets WHERE id=?", (row['id'],))
        db.commit()
        flash("비밀번호가 변경되었습니다. 다시 로그인 해주세요.", "success")
        return redirect(url_for('login'))
    return render_template('reset_password.html', token=token)

@app.route('/reviews', methods=['GET', 'POST'])
def reviews():
    db = get_db()
    user_id = session.get('user_id')
    can_review = False
    user_products = []
    if user_id and user_id != 'pee':
        user_products = db.execute("""
            SELECT DISTINCT pr.id, pr.name
            FROM purchases p
            JOIN products pr ON p.product_id = pr.id
            WHERE p.user_id=?
        """, (user_id,)).fetchall()
        can_review = bool(user_products)
    if request.method == 'POST':
        if not user_id or user_id == 'pee':
            flash('로그인 후 이용하세요.', 'danger')
            return redirect(url_for('reviews'))
        product_id = request.form.get('product_id')
        content = request.form.get('content')
        purchased = db.execute(
            "SELECT * FROM purchases WHERE user_id=? AND product_id=?",
            (user_id, product_id)
        ).fetchone()
        if not purchased:
            flash('해당 상품을 구매한 경우만 후기를 남길 수 있습니다.', 'danger')
        elif not content.strip():
            flash('후기 내용을 입력하세요.', 'danger')
        else:
            db.execute("INSERT INTO reviews (user_id, product_id, content) VALUES (?, ?, ?)",
                       (user_id, product_id, content))
            db.commit()
            flash('구매후기가 등록되었습니다.', 'success')
        return redirect(url_for('reviews'))
    reviews = db.execute("""
        SELECT r.*, u.username, p.name as product_name
        FROM reviews r
        JOIN users u ON r.user_id = u.id
        JOIN products p ON r.product_id = p.id
        ORDER BY r.created_at DESC
    """).fetchall()
    return render_template('reviews.html', reviews=reviews, can_review=can_review, user_products=user_products)

@app.route('/admin_coupons', methods=['GET', 'POST'])
def admin_coupons():
    if not session.get('is_admin'):
        flash('관리자만 접근 가능합니다.', 'danger')
        return redirect(url_for('login'))
    db = get_db()
    if request.method == 'POST':
        code = request.form.get('code', '').strip()
        description = request.form.get('description', '').strip()
        amount = request.form.get('amount', '').strip()
        max_uses = request.form.get('max_uses', '').strip()
        if not code or not amount or not max_uses:
            flash('쿠폰코드, 금액, 최대 사용횟수는 필수입니다.', 'danger')
        else:
            try:
                amount = int(amount)
                max_uses = int(max_uses)
                db.execute("INSERT INTO coupons (code, description, amount, max_uses) VALUES (?, ?, ?, ?)",
                           (code, description, amount, max_uses))
                db.commit()
                flash('쿠폰이 등록되었습니다.', 'success')
            except sqlite3.IntegrityError:
                flash('이미 존재하는 쿠폰코드입니다.', 'danger')
            except Exception:
                flash('쿠폰 등록에 실패했습니다.', 'danger')
        return redirect(url_for('admin_coupons'))
    coupons = db.execute("SELECT * FROM coupons ORDER BY id DESC").fetchall()
    return render_template('admin_coupons.html', coupons=coupons)

@app.route('/use_coupon', methods=['GET', 'POST'])
def use_coupon():
    if 'user_id' not in session or session['user_id'] == 'pee':
        flash('로그인 후 이용하세요.', 'danger')
        return redirect(url_for('login'))
    db = get_db()
    if request.method == 'POST':
        code = request.form.get('code', '').strip()
        coupon = db.execute("SELECT * FROM coupons WHERE code=?", (code,)).fetchone()
        if not coupon:
            flash('존재하지 않는 쿠폰입니다.', 'danger')
            return redirect(url_for('use_coupon'))
        if coupon['max_uses'] - coupon['used_count'] < 1:
            flash('만료된 쿠폰입니다.', 'danger')
            return redirect(url_for('use_coupon'))
        used = db.execute("SELECT * FROM coupon_usages WHERE user_id=? AND coupon_id=?", (session['user_id'], coupon['id'])).fetchone()
        if used:
            flash('이미 사용한 쿠폰입니다.', 'danger')
            return redirect(url_for('use_coupon'))
        db.execute("UPDATE users SET points=points+? WHERE id=?", (coupon['amount'], session['user_id']))
        db.execute("UPDATE coupons SET used_count=used_count+1 WHERE id=?", (coupon['id'],))
        db.execute("INSERT INTO coupon_usages (user_id, coupon_id) VALUES (?,?)", (session['user_id'], coupon['id']))
        db.commit()
        flash(f'{coupon["amount"]}포인트가 지급되었습니다! (쿠폰 사용 완료)', 'success')
        return redirect(url_for('use_coupon'))
    return render_template('use_coupon.html')

if __name__ == '__main__':
    init_db()
    app.run(host="0.0.0.0",port=2048)